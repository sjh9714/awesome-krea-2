# Wildcards

475 prompts from [this catalog](https://github.com/sjh9714/krea2-wildcards),
one per line, ready for a wildcard or dynamic-prompt node.

- `all.txt`. Every prompt, 475 lines
- one file per category (61 of them), if you want to sample within a style

## ComfyUI

Drop this folder into `ComfyUI/wildcards/`, then reference it from a dynamic
prompt node:

```
__all__
__photography__
__typography__
```

## What is not in here

**The seeds, and you probably do not want them anyway.** A wildcard file is one
prompt per line and has nowhere to put a seed. More to the point, the seeds in
this catalog were recorded against fal's hosted `krea-2/turbo`, which publishes
no step count, CFG, sampler or scheduler. In your own graph the same seed gives
a different image. Take the prompts, pick your own seed, and read
[REPRODUCING.md](../REPRODUCING.md) before you try to match a specific frame.

**The failures.** 65 generations were cut and they are
deliberately excluded, a wildcard file that occasionally serves a
known-broken prompt is worse than none. They are still in the repository,
with the reason each one failed.

Regenerate with `python3 build_wildcards.py`.
